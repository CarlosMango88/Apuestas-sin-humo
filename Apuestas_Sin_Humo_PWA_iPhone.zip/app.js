const $ = id => document.getElementById(id);
const clamp = (n,min,max)=>Math.max(min,Math.min(max,n));
const pct = n => Math.round(clamp(n,0,0.99)*100);
const fair = p => p>0 ? (1/p).toFixed(2) : '--';

const presets = {
  'aus-egy': {home:'Australia', away:'Egipto', hGoals:.67,hConceded:.67,hxG:.69,hSOT:3.7,hCorners:4.0,aGoals:1.67,aConceded:1.0,axG:1.64,aSOT:4.7,aCorners:4.0},
  'arg-cpv': {home:'Argentina', away:'Cabo Verde', hGoals:2.67,hConceded:.33,hxG:1.99,hSOT:5.0,hCorners:3.0,aGoals:.67,aConceded:.67,axG:.82,aSOT:2.3,aCorners:3.0},
  'col-gha': {home:'Colombia', away:'Ghana', hGoals:1.3,hConceded:.3,hxG:1.43,hSOT:6.3,hCorners:4.7,aGoals:.7,aConceded:.7,axG:.69,aSOT:1.3,aCorners:2.0}
};

function poisson(lambda,k){return Math.exp(-lambda)*Math.pow(lambda,k)/factorial(k)}
function factorial(n){let r=1; for(let i=2;i<=n;i++)r*=i; return r}
function read(){return {
 home:$('homeTeam').value||'Local', away:$('awayTeam').value||'Visitante',
 hGoals:+$('hGoals').value,hConceded:+$('hConceded').value,hxG:+$('hxG').value,hSOT:+$('hSOT').value,hCorners:+$('hCorners').value,
 aGoals:+$('aGoals').value,aConceded:+$('aConceded').value,axG:+$('axG').value,aSOT:+$('aSOT').value,aCorners:+$('aCorners').value
}}
function expected(d){
 const hLam = clamp((d.hGoals*0.30 + d.hxG*0.45 + d.aConceded*0.25),0.15,3.8);
 const aLam = clamp((d.aGoals*0.30 + d.axG*0.45 + d.hConceded*0.25),0.15,3.8);
 return {hLam,aLam,total:hLam+aLam,corners:clamp(d.hCorners+d.aCorners,2,15)};
}
function calc(d){
 const e=expected(d); let home=0,draw=0,away=0,over15=0,over25=0,btts=0;
 for(let h=0;h<=7;h++)for(let a=0;a<=7;a++){const p=poisson(e.hLam,h)*poisson(e.aLam,a); if(h>a)home+=p; else if(h===a)draw+=p; else away+=p; if(h+a>=2)over15+=p; if(h+a>=3)over25+=p; if(h>0&&a>0)btts+=p;}
 const cornerOver65 = 1-[0,1,2,3,4,5,6].reduce((s,k)=>s+poisson(e.corners,k),0);
 const cornerOver75 = 1-[0,1,2,3,4,5,6,7].reduce((s,k)=>s+poisson(e.corners,k),0);
 const hMoreSOT = clamp(.5 + (d.hSOT-d.aSOT)*.075, .08,.95);
 const hMoreCorners = clamp(.5 + (d.hCorners-d.aCorners)*.07, .10,.92);
 const awayUnder15 = poisson(e.aLam,0)+poisson(e.aLam,1);
 const homeUnder15 = poisson(e.hLam,0)+poisson(e.hLam,1);
 return {e, markets:[
  [`${d.home} gana`,home],['Empate',draw],[`${d.away} gana`,away],['Over 1.5 goles',over15],['Over 2.5 goles',over25],['Ambos marcan',btts],['Over 6.5 córners',cornerOver65],['Over 7.5 córners',cornerOver75],[`${d.home} más tiros a puerta`,hMoreSOT],[`${d.home} más córners`,hMoreCorners],[`${d.away} menos de 1.5 goles`,awayUnder15],[`${d.home} menos de 1.5 goles`,homeUnder15]
 ].sort((a,b)=>b[1]-a[1])};
}
function render(){
 const d=read(); $('homeTitle').textContent=d.home; $('awayTitle').textContent=d.away;
 const r=calc(d); const top=r.markets[0]; $('globalScore').textContent=pct(top[1])+'%';
 $('summary').innerHTML = `<div class="metric"><span>Goles esperados</span><strong>${r.e.total.toFixed(2)}</strong></div><div class="metric"><span>Córners esperados</span><strong>${r.e.corners.toFixed(1)}</strong></div><div class="metric"><span>${d.home} xG ajustado</span><strong>${r.e.hLam.toFixed(2)}</strong></div><div class="metric"><span>${d.away} xG ajustado</span><strong>${r.e.aLam.toFixed(2)}</strong></div>`;
 $('markets').innerHTML = r.markets.map(([name,p])=>`<div class="market"><div><strong>${name}</strong><div class="bar"><div class="fill" style="width:${pct(p)}%"></div></div></div><div class="prob">${pct(p)}%</div></div>`).join('');
 $('evTable').innerHTML = r.markets.slice(0,8).map(([name,p],i)=>`<div class="evrow"><div><strong>${name}</strong><br><small>Prob. ${pct(p)}% | cuota justa ${fair(p)}</small></div><input type="number" step="0.01" placeholder="Cuota" data-p="${p}"><div class="ev" id="ev${i}">--</div></div>`).join('');
 document.querySelectorAll('#evTable input').forEach((inp,i)=>inp.addEventListener('input',()=>{const p=+inp.dataset.p, odds=+inp.value; const ev=(p*odds-1)*100; const el=$('ev'+i); el.textContent=odds?`${ev>0?'+':''}${ev.toFixed(1)}%`:'--'; el.style.color=ev>0?'#26d07c':'#ff6b6b'}));
}
function loadPreset(key){const p=presets[key]; if(!p)return; $('homeTeam').value=p.home; $('awayTeam').value=p.away; ['hGoals','hConceded','hxG','hSOT','hCorners','aGoals','aConceded','axG','aSOT','aCorners'].forEach(k=>$(k).value=p[k]); render();}
$('analyze').addEventListener('click', render);
document.querySelectorAll('[data-preset]').forEach(b=>b.addEventListener('click',()=>loadPreset(b.dataset.preset)));
['homeTeam','awayTeam','hGoals','hConceded','hxG','hSOT','hCorners','aGoals','aConceded','axG','aSOT','aCorners'].forEach(id=>$(id).addEventListener('input',render));
if('serviceWorker' in navigator){navigator.serviceWorker.register('./sw.js').catch(()=>{})}
render();
